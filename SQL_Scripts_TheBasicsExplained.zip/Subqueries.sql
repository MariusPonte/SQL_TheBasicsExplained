USE TEMPDB

IF OBJECT_ID ('Person') IS NOT NULL DROP TABLE Person
CREATE TABLE Person ( PersonID INT IDENTITY (6000,1), 
				  LastName VARCHAR (50), 
				  Firstname VARCHAR (50) )

INSERT INTO Person VALUES ('Peters', 'Mike')
INSERT INTO Person VALUES ('Smith', 'Joanne')
INSERT INTO Person VALUES ('Roberts', 'Michelle')
INSERT INTO Person VALUES ('White', 'Martha' )
INSERT INTO Person VALUES ('Johansson', 'Gianna' )


IF OBJECT_ID ('Orders') IS NOT NULL DROP TABLE Orders
CREATE TABLE Orders ( OrderID INT IDENTITY (1000, 1), 
				  PersonID INT, 
				  OrderDate DATE, 
				  OrderPrice MONEY,
				  OrderDescription VARCHAR(100))

INSERT INTO Orders VALUES (6000, '2018-01-30', '5.25', 'Fruit')
INSERT INTO Orders VALUES (6001, '2018-05-25', '7.80', 'Vegetables')
INSERT INTO Orders VALUES (6002, '2018-08-15', '1.25', 'Cookie')
INSERT INTO Orders VALUES (6000, '2018-12-14', '0.80', 'Milk')
INSERT INTO Orders VALUES (6001, '2018-08-04', '4.15', 'Potatoes')
INSERT INTO Orders VALUES (6002, '2018-04-02', '2.15', 'Tomatos')
INSERT INTO Orders VALUES (6000, '2018-02-06', '7.40', 'Beef')
INSERT INTO Orders VALUES (6001, '2018-03-16', '1.60', 'Eggs')
INSERT INTO Orders VALUES (6002, '2018-09-01', '2.05', 'Juice')
INSERT INTO Orders VALUES (6003, '2018-01-31', '3.20', 'Strawberry')
INSERT INTO Orders VALUES (NULL, '2018-04-30', '4.50', 'Cake')

SELECT * 
FROM Person AS P
WHERE PersonID IN ( SELECT PersonID FROM Orders )

SELECT P.* 
FROM Person AS P
WHERE PersonID IN ( SELECT PersonID
				FROM Orders 
				WHERE OrderPrice > ( SELECT AVG (OrderPrice) FROM Orders AS O2 ) ) 

SELECT * 
FROM Orders AS O
WHERE NOT EXISTS ( SELECT * FROM Orders AS O2
			    WHERE O.PersonID = O2.PersonID
			      AND O.OrderDate < O2.OrderDate )


DROP TABLE Person
DROP TABLE Orders