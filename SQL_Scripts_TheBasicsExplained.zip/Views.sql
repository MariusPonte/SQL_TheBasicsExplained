
CREATE TABLE Person (PersonID INT, FullName VARCHAR (50), Country VARCHAR (20))
INSERT INTO Person VALUES (2001, 'Lia Randolfs', 'France'),
					 (2002, 'Will Van Dam', 'USA'),
					 (2003, 'Patricia Suez', 'Spain')

CREATE TABLE Transactions (TranID INT, PersonID INT, TranAmount MONEY, TranDate DATE)
INSERT INTO Transactions VALUES (9000, 2001, 20.15, '20180501'),
						   (9001, 2001, 40.30, '20180508'),
						   (9002, 2002, 819.15, '20180620'),
						   (9003, 2003, 71.95, '20180708'),
						   (9004, 2003, 8.15, '20180820');

SELECT P.*, T.TranID, T.TranDate, T.TranAmount
FROM Person AS P
INNER JOIN Transactions AS T ON P.PersonID = T.PersonID

CREATE VIEW v_TransactionsPerPerson AS 

(
    SELECT P.*, T.TranID, T.TranDate, T.TranAmount
    FROM Person AS P
    INNER JOIN Transactions AS T ON P.PersonID = T.PersonID
)

SELECT * FROM v_TransactionsPerPerson

DROP TABLE Person, Transactions
DROP VIEW v_TransactionsPerPerson

