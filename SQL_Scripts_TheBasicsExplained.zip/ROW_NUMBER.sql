
USE TEMPDB

IF OBJECT_ID ('Person') IS NOT NULL DROP TABLE Person
CREATE TABLE Person ( PersonID INT IDENTITY (6000,1), 
				  LastName VARCHAR (50), 
				  Firstname VARCHAR (50) )

INSERT INTO Person VALUES ('Peters', 'Mike')
INSERT INTO Person VALUES ('Smith', 'Joanne')
INSERT INTO Person VALUES ('Roberts', 'Michelle')
INSERT INTO Person VALUES ('White', 'Martha' )
INSERT INTO Person VALUES ('Johansson', 'Gianna' )

SELECT *, ROW_NUMBER() OVER (ORDER BY NEWID()) AS RowNumb 
INTO PersNew 
FROM Person

SELECT * FROM PersNew

IF OBJECT_ID ('Codes') IS NOT NULL DROP TABLE Codes
CREATE TABLE Codes ( Codes VARCHAR (6) )
INSERT INTO Codes VALUES ('88ABC9'), ('65OPQ8'), ('LL47L8'), ('TY412B'), ('33H0TR')

SELECT *, ROW_NUMBER() OVER (ORDER BY NEWID()) AS RowNumb INTO PersNew FROM Person

SELECT *, ROW_NUMBER() OVER (ORDER BY NEWID()) AS RowNumb INTO CodesNew FROM Codes

SELECT P.PersonID, P.LastName, P.Firstname, Codes AS Code 
FROM PersNew AS P
INNER JOIN CodesNew AS C ON C.RowNumb = P.RowNumb

CREATE TABLE Stocks (Item VARCHAR (100), DateColumn DATETIME, Stockprice MONEY)
INSERT INTO Stocks VALUES ('EnergyStock', '2018-10-26 16:38:46.897', '16.15')
INSERT INTO Stocks VALUES ('EconomyStock', '2018-10-24 18:01:01.000', '57.00')
INSERT INTO Stocks VALUES ('EnergyStock', '2018-10-26 17:00:00.000', '16.12')
INSERT INTO Stocks VALUES ('EconomyStock', '2018-10-25 17:00:00.000', '54.88')
INSERT INTO Stocks VALUES ('EnergyStock', '2018-10-26 18:00:00.000', '17.11')
INSERT INTO Stocks VALUES ('EconomyStock', '2018-10-25 18:00:00.000', '58.11')

SELECT * FROM Stocks

SELECT *, ROW_NUMBER() OVER (PARTITION BY Item ORDER BY DateColumn) AS RowNumb 
INTO StockRows
FROM Stocks

SELECT S.Item, 
	  S.DateColumn AS PrevDate,
	  S.StockPrice AS PrevStockPrice,
	  ISNULL (S2.StockPrice, '') AS NextStockPrice,
	  ISNULL (S2.StockPrice - S.StockPrice, '') AS Delta
FROM StockRows AS S
LEFT JOIN Stockrows AS S2 ON S.RowNumb = S2.RowNumb + 1 AND S.Item = S2.Item

DROP TABLE Stocks, CodesNew, PersNew, Codes, Person