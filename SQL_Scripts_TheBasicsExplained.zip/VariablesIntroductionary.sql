CREATE TABLE #Orders (OrderID INT, OrderQuantity INT, ItemPrice MONEY, OrderDate DATETIME)
INSERT INTO #Orders VALUES (45, 2, 45.01, GETDATE() - 10),
					  (46, 1, 25.92, GETDATE() - 9),
					  (54, 3, 13.13, GETDATE() - 8),
					  (88, 8, 13.14, GETDATE() - 7),
					  (64, 5, 35.14, GETDATE() - 6),
					  (66, 6, 65.85, GETDATE() - 5),
					  (71, 2, 15.85, GETDATE() - 4),
					  (45, 5, 45.15, GETDATE() - 3),
					  (48, 6, 5.15, GETDATE() - 2),
					  (49, 6, 32.45, GETDATE() - 1),
					  (12, 7, 85.45, GETDATE() - 10),
					  (13, 8, 25.45, GETDATE() - 9),
					  (11, 9, 28.45, GETDATE() - 8),
					  (66, 6, 35.35, GETDATE() - 7),
					  (33, 7, 18.35, GETDATE() - 6),
					  (15, 3, 85.25, GETDATE() - 5),
					  (19, 4, 57.25, GETDATE() - 4),
					  (27, 7, 79.15, GETDATE() - 3),
					  (28, 6, 65.05, GETDATE() - 2),
					  (44, 7, 95.85, GETDATE() - 1)

DECLARE @StartDate DATETIME
DECLARE @EndDate DATETIME

SET @StartDate = GETDATE() - 14
SET @EndDate = GETDATE() - 7

SELECT OrderID, OrderQuantity, ItemPrice
FROM #Orders
WHERE OrderDate >= @StartDate
  AND OrderDate <= @EndDate


DECLARE @StartDate DATETIME
DECLARE @EndDate DATETIME

SET @StartDate = GETDATE() - 14
SET @EndDate = GETDATE() - 7

SELECT OrderID, 
	  OrderQuantity, 
	  ItemPrice, 
	  OrderQuantity * ItemPrice AS OrderPrice,
	  ( SELECT AVG (OrderQuantity * ItemPrice) 
	    FROM #Orders AS O2 
	    WHERE OrderDate >= @StartDate 
		 AND OrderDate <= @EndDate ) AS AverageOrderPrice
FROM #Orders
WHERE OrderDate >= @StartDate
  AND OrderDate <= @EndDate


-- DOIN' IT WRONG

DECLARE @StartDate DATETIME
DECLARE @EndDate DATETIME

SET @StartDate = GETDATE() - 14
SET @EndDate = GETDATE() - 7

SELECT OrderID, 
	  OrderQuantity, 
	  ItemPrice, 
	  OrderQuantity * ItemPrice AS OrderPrice,
	  AVG ( OrderQuantity * ItemPrice ) AS AverageOrderPrice
FROM #Orders
WHERE OrderDate >= @StartDate
  AND OrderDate <= @EndDate






