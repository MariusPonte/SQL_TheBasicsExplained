
CREATE TABLE Person (PersonID INT, 
                     LastName Varchar (50), 
                     Firstname VARCHAR (50),
                     DateOfBirth DATETIME,
                     CurrentDate DATETIME,
                     AGE INT)
                     
INSERT INTO Person VALUES (5001, 'compans', 'Peter', '19821205', '20180922', 36),
                          (5002, 'deverson', 'Francis', '19740202', '20180922', 44),
                          (5002, 'williams', 'William', '19820520', '20180922', 36),
                          (5004, 'quotu', 'Chi-Mai', '20001015', '20180922', 17),
                          (5005, 'lazovic', 'Kendra', '19990826', '20180922', 19) 

UPDATE Person
SET Age = 35 WHERE Age = 36                     

SELECT * FROM Person

UPDATE Person
SET Age = 36 WHERE Age = 35

SELECT * 
FROM Person
WHERE PersonID = 5001

UPDATE Person
SET Age = 35
WHERE PersonID = 5001

SELECT UPPER (LEFT (LastName, 1)) + LOWER (SUBSTRING (LastName, 2, LEN (LastName))) AS LastName
FROM Person

UPDATE Person
SET Lastname = UPPER (LEFT (LastName, 1)) + LOWER (SUBSTRING (LastName, 2, LEN (LastName))) 

ALTER TABLE Person ADD AgeNew INT

SELECT (0 + CONVERT(CHAR(8),GETDATE(), 112) - CONVERT(CHAR(8), DateOfBirth, 112)) / 10000 AS CalculatedAge, *
FROM Person

UPDATE Person SET AgeNew =
(0 + CONVERT(CHAR(8),GETDATE(), 112) - CONVERT(CHAR(8), DateOfBirth, 112)) / 10000

ALTER TABLE Person DROP COLUMN Age
