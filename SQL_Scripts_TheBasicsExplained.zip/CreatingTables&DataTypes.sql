
USE TEMPDB
CREATE TABLE Person ( PersonID INT,
				  AveragePurchases FLOAT,
				  FullName VARCHAR (50),
				  Age TINYINT,
				  DateOfBirth DATE,
				  MemberSince DATETIME,
				  AverageSpending MONEY,
				  TransactionID UNIQUEIDENTIFIER )

SELECT CAST ('MyName' AS VARCHAR (20)) AS Name1,
	  CONVERT (VARCHAR (20), 'MyName') AS Name2

SELECT CAST ('2001-01-31' AS DATE) AS ColDate,
	  CAST ('2001-01-31' AS SMALLDATETIME) AS ColSmallDateTime,
	  CAST ('2001-01-31' AS DATETIME) AS ColDateTime,
	  CAST ('2001-01-31' AS DATETIME2) AS ColDateTime2
	 
SELECT CAST (1.01 AS FLOAT) AS NumbFloat,
	  CAST (1.91 AS INT) AS NumbInt,
	  CAST (1.01 AS DECIMAL (12,4)) AS NumbDecimal,
	  CAST (1.01 AS MONEY) AS NumbMoney,
	  CAST (1.01 AS NUMERIC (12,4)) AS NumbNumeric

SELECT CAST (2000.001 AS NUMERIC (7,4))	   	  

SELECT CAST (2000.001 AS NUMERIC (7,3))	   	  
SELECT CAST (2000.001 AS NUMERIC (8,4))	   	  


SELECT 1001 AS PersonID,
	  CAST (4.15 AS FLOAT) AS AveragePurchases,
	  CAST ('Leo Hickins' AS VARCHAR (50)) AS FullName,
	  36	AS Age,
	  CAST ('19820530' AS DATE) AS DateOfBirth,
	  CAST (GETDATE() - 910 AS DATETIME) AS MemberSince,
	  CAST (36.15 AS MONEY)	AS AverageSpending,
	  NEWID()	AS TransactionID 
INTO NewTable

INSERT INTO Person 
VALUES (1002, 2.11, 'Tina Fredricks', 19, '1999-06-02', (GETDATE() - 444), 85.04, NEWID()),
	  (1003, 4.41, 'Ron Ivanov', 40, '1978-06-02', (GETDATE() - 1122), 106.04, NEWID())

INSERT INTO Person
SELECT * FROM NewTable

CREATE TABLE SomeOtherTable (PersonID INT, FullName VARCHAR (50), DateOfBirth DATE, Age INT)
INSERT INTO SomeOtherTable VALUES (5001, 'Nicky Fuller', '19780919', 40)

INSERT INTO Person
SELECT PersonID,
	  NULL AS AveragePurchases,
	  FullName,
	  Age,
	  DateOfBirth,
	  NULL,
	  0,
	  NULL
FROM SomeOtherTable

DROP TABLE Person
DROP TABLE SomeOtherTable
DROP TABLE NewTable