USE TEMPDB

IF OBJECT_ID ('Person') IS NOT NULL DROP TABLE Person
CREATE TABLE Person ( PersonID INT IDENTITY (6000,1), 
				  LastName VARCHAR (50), 
				  Firstname VARCHAR (50) )

INSERT INTO Person VALUES ('Peters', 'Mike')
INSERT INTO Person VALUES ('Smith', 'Joanne')
INSERT INTO Person VALUES ('Roberts', 'Michelle')
INSERT INTO Person VALUES ('White', 'Martha' )
INSERT INTO Person VALUES ('Johansson', 'Gianna' )


IF OBJECT_ID ('Orders') IS NOT NULL DROP TABLE Orders
CREATE TABLE Orders ( OrderID INT IDENTITY (1000, 1), 
				  PersonID INT, 
				  OrderDate DATE, 
				  OrderDescription VARCHAR(100))

INSERT INTO Orders VALUES (6000, '2018-01-30', 'Fruit')
INSERT INTO Orders VALUES (6001, '2018-05-25', 'Vegetables')
INSERT INTO Orders VALUES (6002, '2018-08-15', 'Cookie')
INSERT INTO Orders VALUES (6000, '2018-12-14', 'Milk')
INSERT INTO Orders VALUES (6001, '2018-08-04', 'Potatoes')
INSERT INTO Orders VALUES (6002, '2018-04-02', 'Tomatos')
INSERT INTO Orders VALUES (6000, '2018-02-06', 'Beef')
INSERT INTO Orders VALUES (6001, '2018-03-16', 'Eggs')
INSERT INTO Orders VALUES (6002, '2018-09-01', 'Juice')
INSERT INTO Orders VALUES (6003, '2018-01-31', 'Strawberry')
INSERT INTO Orders VALUES (NULL, '2018-04-30', 'Cake')

SELECT * 
FROM Person AS P
INNER JOIN Orders AS O ON O.PersonID = P.PersonID

SELECT * 
FROM Person AS P
LEFT JOIN Orders AS O ON O.PersonID = P.PersonID

SELECT * 
FROM Person AS P
LEFT JOIN Orders AS O ON O.PersonID = P.PersonID
WHERE O.OrderID IS NULL

SELECT * 
FROM Person AS P
FULL OUTER JOIN Orders AS O ON O.PersonID = P.PersonID

SELECT * 
FROM Person AS P
CROSS JOIN Orders AS O

DROP TABLE Person
DROP TABLE Orders