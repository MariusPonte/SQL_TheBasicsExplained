
USE MyDatabase
CREATE TABLE i_Test (ColA INT, ColB VARCHAR (100), ColC UNIQUEIDENTIFIER )

INSERT INTO i_Test VALUES ( 5, 'Hello', NEWID() ),
				      ( 1, 'welcome', NEWID() ),
				      ( 9, 'to', NEWID() ),
				      ( 2, 'My IndexTable', NEWID() )

SELECT * FROM i_Test

CREATE CLUSTERED INDEX i_ColA ON i_Test (ColA)

SELECT * FROM i_Test

DROP TABLE i_Test
CREATE TABLE i_Test (ColA INT NOT NULL, ColB VARCHAR (100), ColC UNIQUEIDENTIFIER )

INSERT INTO i_Test VALUES ( 5, 'Hello', NEWID() ),
				      ( 1, 'welcome', NEWID() ),
				      ( 9, 'to', NEWID() ),
				      ( 2, 'My IndexTable', NEWID() )

ALTER TABLE i_Test ADD CONSTRAINT PK_i_Test_ColA PRIMARY KEY CLUSTERED (ColA)


DROP TABLE i_Test 
CREATE TABLE i_Test (ColA INT NOT NULL, ColB VARCHAR (100), ColC UNIQUEIDENTIFIER )

INSERT INTO i_Test VALUES ( 5, 'Hello', NEWID() ),
				      ( 1, 'welcome', NEWID() ),
				      ( 9, 'to', NEWID() ),
				      ( 2, 'My IndexTable', NEWID() )

SELECT * FROM i_Test WHERE ColB LIKE 'M%'

CREATE NONCLUSTERED INDEX i_ColB ON i_Test (ColB)