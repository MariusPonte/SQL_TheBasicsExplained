
CREATE TABLE #Person (PersonID INT, ColA VARCHAR (5), ColB VARCHAR (5))
INSERT INTO #Person VALUES (1, 'a', 'b'),
					  (2, 'c', 'b'),
					  (3, 'f', 'y'),
					  (4, 't', 'q'),
					  (5, 'a', 'e'),
					  (6, 's', 'w'),
					  (7, 'a', NULL)


CREATE TABLE #Transactions (TranID INT, PersonID INT, ColA VARCHAR (5))
INSERT INTO #Transactions VALUES (8001, 1, 'a'),
						   (8002, NULL, 'c'),
						   (8003, 3, 'f'),
						   (8004, 4, 't'),
						   (8005, 5, NULL),
						   (8006, 6, 's'),
						   (8007, 7, NULL)

SELECT P.*
FROM #Person AS P
WHERE P.PersonID IN ( SELECT T.PersonID FROM #Transactions AS T )

SELECT P.*
FROM #Person AS P
WHERE P.PersonID NOT IN ( SELECT T.PersonID FROM #Transactions AS T )

SELECT P.*
FROM #Person AS P
WHERE P.PersonID NOT IN ( SELECT T.PersonID FROM #Transactions AS T 
					 WHERE T.PersonID IS NOT NULL )

SELECT * FROM #Person AS P
WHERE EXISTS ( SELECT * FROM #Transactions AS T
			WHERE P.PersonID = T.PersonID )


SELECT * FROM #Person AS P
WHERE NOT EXISTS ( SELECT * FROM #Transactions AS T
			    WHERE P.PersonID = T.PersonID )