
IF OBJECT_ID ('TEMPDB..#Person') IS NOT NULL DROP TABLE #Person
CREATE TABLE #Person ( PersonID INT IDENTITY (6000,1), 
				   LastName VARCHAR (50), 
				   Firstname VARCHAR (50) )

INSERT INTO #Person VALUES ('Peters', 'Mike')
INSERT INTO #Person VALUES ('Smith', 'Joanne')
INSERT INTO #Person VALUES ('Roberts', 'Michelle')
INSERT INTO #Person VALUES ('White', 'Martha' )

SELECT * FROM #Person

IF OBJECT_ID ('TEMPDB..#Orders') IS NOT NULL DROP TABLE #Orders
CREATE TABLE #Orders ( OrderID INT IDENTITY (1000, 1), 
				   PersonID INT, 
				   OrderDate DATE, 
				   OrderDescription VARCHAR(100))

INSERT INTO #Orders VALUES (6000, '2018-01-30', 'Fruit')
INSERT INTO #Orders VALUES (6001, '2018-05-25', 'Vegetables')
INSERT INTO #Orders VALUES (6002, '2018-08-15', 'Cookie')
INSERT INTO #Orders VALUES (6000, '2018-12-14', 'Milk')
INSERT INTO #Orders VALUES (6001, '2018-08-04', 'Potatoes')
INSERT INTO #Orders VALUES (6002, '2018-04-02', 'Tomatos')
INSERT INTO #Orders VALUES (6000, '2018-02-06', 'Beef')
INSERT INTO #Orders VALUES (6001, '2018-03-16', 'Eggs')
INSERT INTO #Orders VALUES (6002, '2018-09-01', 'Juice')
INSERT INTO #Orders VALUES (6003, '2018-01-31', 'Strawberry')

SELECT P.*, CrossApply.OrderDate, CrossApply.OrderDescription
FROM #Person AS P
CROSS APPLY ( SELECT TOP 2 * FROM #Orders AS O
		    WHERE P.PersonID = O.PersonID
		    ORDER BY O.OrderDate DESC ) AS CrossApply







