
CREATE TABLE Customers ( CustomerID INT, LastName VARCHAR (20), Firstname VARCHAR (20),
				     DateOfBirth DATE, City VARCHAR (20), Country VARCHAR (20) )
INSERT INTO Customers VALUES (1001, 'Smith', 'Jenny', '19800425', 'London', 'England'),
					    (1002, 'Stow', 'Mitch', '19920131', 'Paris', 'France'),
					    (1003, 'Lenners', 'Martha', '19900415', 'Madrid', 'Spain'),
					    (1004, 'Ivanovic', 'Kyra', '19891202', 'London', 'England'),
					    (1005, 'Johansson', 'Anna', '19990930', 'Nice', 'France'),
					    (1006, 'Flowers', 'Bjorn', '19950120', 'Amsterdam', 'Netherlands'),
					    (1007, 'Jackson', 'Hank', '19700630', 'New York', 'United States')				    

SELECT CustomerID,
	  LastName,
	  Firstname,
	  DateOfBirth,
	  City,
	  Country
FROM Customers

SELECT * FROM Customers

SELECT CustomerID AS CustID,
	  LastName AS 'Last Name',
	  DateOfBirth AS 'Date of Birth'
FROM Customers

SELECT CustomerID + 100 AS NewCustID,				 -- Adding integers
	  Firstname + ' ' + LastName AS FullName,		 -- Adding VARCHARS
	  LEFT (Firstname, 1) + '.' AS FirstLetter,		 -- LEFT function
	  YEAR (DateOfBirth) AS BirthYear,				 -- Getting the year from a date
	  MONTH (DateOfBirth) AS MonthOfBirth,			 -- Getting the month of a date
	  UPPER (LEFT (Country, 3)) AS CountryAbbreviation -- First three letters, Uppercase
FROM Customers	
   
DROP TABLE Customers