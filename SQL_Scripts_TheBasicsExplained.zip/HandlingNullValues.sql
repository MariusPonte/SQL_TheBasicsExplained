CREATE TABLE  #P (PersonID INT)
INSERT INTO #P VALUES (1), (2), (3)

SELECT * 
FROM  #P
WHERE NULL = NULL

SELECT * 
FROM #P
WHERE NULL <> NULL

SELECT NULL / 0 -- normally dividing by zero would throw an error

SELECT ISNULL (NULL, '') AS EmptyString

SELECT NULLIF (0, 0) AS CreatingNulls 

CREATE TABLE #ProductsPurchased (ProductID INT, TotalRevenue MONEY, Purchases INT)
INSERT INTO #ProductsPurchased VALUES (1, 112.25, 7)
INSERT INTO #ProductsPurchased VALUES (2, NULL, NULL)
INSERT INTO #ProductsPurchased VALUES (3, 456.80, 0)
INSERT INTO #ProductsPurchased VALUES (4, 944, 6)
INSERT INTO #ProductsPurchased VALUES (5, 47.50, 4)

SELECT * 
FROM #ProductsPurchased
WHERE Purchases = 0 OR Purchases IS NULL

SELECT * 
FROM #ProductsPurchased
WHERE ISNULL (Purchases, 0) = 0 

SELECT *, 
	  TotalRevenue / Purchases AS UnitPrice
FROM #ProductsPurchased

SELECT *, 
	  TotalRevenue / NULLIF (Purchases, 0) AS UnitPrice
FROM #ProductsPurchased